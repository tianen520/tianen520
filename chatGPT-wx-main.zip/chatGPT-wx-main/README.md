TG群：https://t.me/+X_W1P9MLinE0MDk1
微信群加我拉技术交流群

![d6520e54fbfadd318a42dbe3a08a4d0](https://user-images.githubusercontent.com/48462615/225180177-78ad7463-f2d2-4216-b12b-9ae053f16507.jpg)

# chatGPT-wx
关于由openAI公司发布的大型预训练语言模型chatGPT接入微信小程序.

# 后端代码在公众号：Web3研究工厂
# chatGPT机器人体验 在公众号：
![69e59d4bc547256c0b0cd3ebc5415a5](https://user-images.githubusercontent.com/48462615/222143450-d9c69d6f-8654-4048-8988-61ee157b77cb.png)
或者直接小程序搜索：GG智能聊天AI机器人


有问题加我微信吧   备注chatGPT
![code(1)](https://user-images.githubusercontent.com/48462615/223733225-44475a84-7d97-4011-89cf-7acad9128ca6.jpg)
